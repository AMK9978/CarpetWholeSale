# CarpetWholeSale
A carpet wholsale manager android app for sellers and buying system for buyers.
Created by Mehrnoush Alipour and Amir Muhammad Karimi.
