package com.example.launcher.myapplication.Intro;

import android.support.v4.app.Fragment;

public class ThirdIntro extends Fragment {
}
